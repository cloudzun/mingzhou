#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""素材完整性校验：先跑它，再开工。

期望（素材指纹）：
  30 份合同 / 合同内容合并哈希固定 / 规则 27 条且含立场 / 单元样本 60（30+20+10）/ 锚点 20

用法：python eval/check_starter.py
退出码：0 = 全部通过；1 = 有不通过项（停手，先修素材）
"""
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONTRACTS = ROOT / "materials" / "contracts"
RULES = ROOT / "rules" / "rules.yaml"
UNITS = ROOT / "truth" / "units_sample.jsonl"
ANCHORS = ROOT / "truth" / "anchors.jsonl"

EXPECT_CONTRACTS = 30
EXPECT_CONTENT_HASH = "7fd9a1f30d93684f9381bca994e82fcf563f9f9e29195f24713a189b8494ead3"
EXPECT_RULES = 27
EXPECT_UNITS = {"exist": 30, "missing": 20, "semantic": 10}
EXPECT_ANCHORS = 20

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def docx_content_hash(files):
    parts = []
    for f in sorted(files, key=lambda p: p.name):
        with zipfile.ZipFile(f) as z:
            data = z.read("word/document.xml")
        parts.append(f.name + ":" + hashlib.sha256(data).hexdigest())
    joined = "\n".join(parts).encode("utf-8")
    return hashlib.sha256(joined).hexdigest()


def main() -> int:
    files = sorted(CONTRACTS.glob("CT*.docx")) if CONTRACTS.exists() else []
    check(f"合同数 = {EXPECT_CONTRACTS}", len(files) == EXPECT_CONTRACTS, f"实际 {len(files)}")
    if files:
        h = docx_content_hash(files)
        check("合同内容指纹一致", h == EXPECT_CONTENT_HASH, h[:12] + "…")

    if not RULES.exists():
        check("规则清单存在", False, "缺少 rules/rules.yaml")
    else:
        text = RULES.read_text(encoding="utf-8-sig")
        n = len(re.findall(r"\{id:\s*R\d+", text))
        check(f"规则数 = {EXPECT_RULES}", n == EXPECT_RULES, f"实际 {n}")
        check("含立场声明（stance: 甲方）", bool(re.search(r"stance:\s*甲方", text)), "rules.yaml 顶部应有 stance")

    if not UNITS.exists():
        check("判定单元样本存在", False, "缺少 truth/units_sample.jsonl")
    else:
        rows = [json.loads(x) for x in UNITS.read_text(encoding="utf-8-sig").splitlines() if x.strip()]
        check(f"单元样本 = {sum(EXPECT_UNITS.values())}", len(rows) == sum(EXPECT_UNITS.values()), f"实际 {len(rows)}")
        buckets = {"exist": 0, "missing": 0, "semantic": 0}
        for r in rows:
            rid = r.get("rule_id", "")
            m = re.match(r"R(\d+)", rid)
            k = int(m.group(1)) if m else -1
            if 1 <= k <= 8:
                buckets["exist"] += 1
            elif 9 <= k <= 13:
                buckets["missing"] += 1
            elif 20 <= k <= 25:
                buckets["semantic"] += 1
        for key, label in (("exist", "存在型 R01–R08"), ("missing", "缺失型 R09–R13"), ("semantic", "语义型 R20–R25")):
            check(f"{label} = {EXPECT_UNITS[key]}", buckets[key] == EXPECT_UNITS[key], f"实际 {buckets[key]}")
        need = {"contract_id", "rule_id", "present", "risk", "level"}
        bad = [r.get("rule_id") for r in rows if not need.issubset(r.keys())]
        check("单元字段齐全", not bad, "缺字段: " + ",".join(bad[:5]) if bad else "")

    if not ANCHORS.exists():
        check("锚点集存在", False, "缺少 truth/anchors.jsonl")
    else:
        n = len([x for x in ANCHORS.read_text(encoding="utf-8-sig").splitlines() if x.strip()])
        check(f"锚点 = {EXPECT_ANCHORS}", n == EXPECT_ANCHORS, f"实际 {n}")

    width = max(len(n) for n, _, _ in results)
    failed = 0
    for name, ok, detail in results:
        if not ok:
            failed += 1
        print(f"[{'PASS' if ok else 'FAIL'}] {name.ljust(width)}  {detail}")
    print("-" * 62)
    if failed:
        print(f"{failed} 项不通过：停手，先修素材（不要把素材问题当代码问题）")
        return 1
    print("全部通过：素材指纹与你拿到的一致，可以开工。")
    print("提示：语义规则 R20–R25 的判定必须带证据与立场，缺一条都会退回乱报。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
