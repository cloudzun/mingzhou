#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""素材完整性校验：先跑它，再开工。

期望（素材指纹）：
  文档数 12 / 正文字符合计 19121 / manifest 文件 sha256 固定 / 评估集 20 题（15 可答 + 5 应拒答）

用法：
  python eval/check_starter.py
退出码：0 = 全部通过；1 = 有不通过项（停手，先修素材）
"""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CORPUS = ROOT / "docs" / "制度库"
MANIFEST = CORPUS / "manifest.json"
EVAL_SET = ROOT / "eval" / "starter_set.jsonl"

EXPECT_DOCS = 12
EXPECT_CHARS = 23489  # 文件全文字符数（换行统一为 LF）；manifest 里的 char_count 只统计正文条款文本，故合计 19121
EXPECT_MANIFEST_SHA256 = "094a3376591ce8d28ec9992cfd1c48813cac5807284ab5fcb18d06ea831b6822"
EXPECT_EVAL_LINES = 20
EXPECT_ANSWERABLE = 15
MIN_CLAUSES_PER_DOC = 23

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def main() -> int:
    if not MANIFEST.exists():
        print(f"缺少 {MANIFEST}")
        return 1

    manifest = json.loads(MANIFEST.read_text(encoding="utf-8-sig"))
    check("manifest 文档数 = %d" % EXPECT_DOCS, len(manifest) == EXPECT_DOCS, f"实际 {len(manifest)}")
    check(
        "manifest 文件 sha256 一致",
        sha256_of(MANIFEST) == EXPECT_MANIFEST_SHA256,
        sha256_of(MANIFEST)[:16] + "…",
    )

    total_chars = 0
    per_doc_ok = True
    for entry in manifest:
        path = CORPUS / entry["file"]
        if not path.exists():
            check(f"存在 {entry['file']}", False, "文件缺失")
            per_doc_ok = False
            continue
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            check(f"指纹 {entry['file']}", False, "sha256 与 manifest 不符（被改过？）")
            per_doc_ok = False
        text = raw.decode("utf-8")
        total_chars += len(text.replace("\r\n", "\n"))
        clauses = len(re.findall(r"第[一二三四五六七八九十百]+条", text))
        if clauses < MIN_CLAUSES_PER_DOC:
            check(f"条款标记 {entry['file']}", False, f"仅 {clauses} 处，应 >= {MIN_CLAUSES_PER_DOC}")
            per_doc_ok = False
    check("逐份文件存在且指纹一致", per_doc_ok)
    check("文件全文字符合计 = %d" % EXPECT_CHARS, total_chars == EXPECT_CHARS, f"实际 {total_chars}")

    if not EVAL_SET.exists():
        check("评估集存在", False, "缺失 starter_set.jsonl")
    else:
        rows = [json.loads(x) for x in EVAL_SET.read_text(encoding="utf-8-sig").splitlines() if x.strip()]
        check("评估集条数 = %d" % EXPECT_EVAL_LINES, len(rows) == EXPECT_EVAL_LINES, f"实际 {len(rows)}")
        ans = [r for r in rows if r.get("answerable")]
        check("可答题 = %d" % EXPECT_ANSWERABLE, len(ans) == EXPECT_ANSWERABLE, f"实际 {len(ans)}")
        need = {"qid", "split", "question", "answerable", "expect_answer_points", "expect_source"}
        bad = [r.get("qid") for r in rows if not need.issubset(r.keys())]
        check("评估集字段齐全", not bad, "缺字段: " + ", ".join(bad[:5]) if bad else "")
        no_src = [r["qid"] for r in ans if not r.get("expect_source")]
        check("可答题都有期望出处", not no_src, "缺出处: " + ", ".join(no_src[:5]) if no_src else "")
        splits = {}
        for r in rows:
            splits[r["split"]] = splits.get(r["split"], 0) + 1
        check("四个分桶都有题", all(splits.get(k) for k in ("conflict_or_stale", "single_hop", "multi_hop", "unanswerable")), str(splits))

    width = max(len(n) for n, _, _ in results)
    failed = 0
    for name, ok, detail in results:
        mark = "PASS" if ok else "FAIL"
        if not ok:
            failed += 1
        print(f"[{mark}] {name.ljust(width)}  {detail}")

    print("-" * 60)
    if failed:
        print(f"{failed} 项不通过：停手，先修素材（不要把素材问题当代码问题）")
        return 1
    print("全部通过：素材指纹与你拿到的一致，可以开工。")
    print("提示：这三组值（12 / 23489 / sha256）以后每次重建索引都要再对一遍。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
