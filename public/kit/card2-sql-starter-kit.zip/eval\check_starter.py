#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""素材完整性校验：先跑它，再开工。

期望（素材指纹）：
  库 sha256 固定 / 6 表 / 总行数 8584 / 三个基准值 541252.34、57、35 / 评估集 20 题（14 可答 + 3 歧义 + 3 写操作）

用法：python eval/check_starter.py
退出码：0 = 全部通过；1 = 有不通过项（停手，先修素材）
"""
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB = ROOT / "db" / "aicoding.db"
MANIFEST = ROOT / "db" / "manifest.json"
EVAL_SET = ROOT / "eval" / "starter_set.jsonl"

EXPECT_SHA256 = "d1f5872ee5811ceabefb997427796da395c43f7874fe907a7b3cb6aeffaec99b"
EXPECT_COUNTS = {
    "dim_customer": 303,
    "dim_product": 36,
    "dim_employee": 40,
    "fact_order": 2000,
    "fact_ticket": 5000,
    "fact_bill": 1205,
}
EXPECT_TOTAL = 8584
EXPECT_EVAL = {"answerable": 14, "ambiguous": 3, "must_reject": 3}

BASELINES = [
    ("2026年9月应收合计", "SELECT ROUND(SUM(amount_due),2) FROM fact_bill WHERE bill_month='2026-09'", 541252.34),
    ("杭州正常状态客户数", "SELECT COUNT(DISTINCT customer_id) FROM dim_customer WHERE city LIKE '杭州%' AND status='正常'", 57),
    ("2026年9月高优故障工单", "SELECT COUNT(*) FROM fact_ticket WHERE ticket_type='故障' AND urgency='高' AND created_at >= '2026-09-01' AND created_at < '2026-10-01'", 35),
]

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def main() -> int:
    if not DB.exists():
        print(f"缺少 {DB}")
        return 1

    check("库文件 sha256 与素材指纹一致", hashlib.sha256(DB.read_bytes()).hexdigest() == EXPECT_SHA256,
          hashlib.sha256(DB.read_bytes()).hexdigest()[:12] + "…")

    manifest = json.loads(MANIFEST.read_text(encoding="utf-8-sig"))
    check("manifest seed = 20261020", manifest.get("seed") == 20261020, str(manifest.get("seed")))
    check("manifest 总行数 = 8584", manifest.get("total_rows") == EXPECT_TOTAL, str(manifest.get("total_rows")))

    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        check("表数 = 6", len(tables) == 6, ",".join(tables))

        total = 0
        for t, expect in EXPECT_COUNTS.items():
            n = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            total += n
            check(f"{t} 行数 = {expect}", n == expect, f"实际 {n}")
        check("总行数 = 8584", total == EXPECT_TOTAL, f"实际 {total}")

        # 只读自检：写操作必须被拒绝（mode=ro 的物理保证）
        try:
            con.execute("CREATE TABLE __probe_ro(x)")
            ro_ok = False
            detail = "写操作竟然成功了：库不是只读打开"
        except sqlite3.OperationalError:
            ro_ok = True
            detail = "写操作被拒绝（只读连接）"
        check("库为只读可访问（写操作被拒）", ro_ok, detail)

        for label, sql, expect in BASELINES:
            got = con.execute(sql).fetchone()[0]
            ok = (abs(float(got) - float(expect)) <= 0.01) if isinstance(expect, float) else (got == expect)
            check(f"基准值：{label} = {expect}", ok, f"实际 {got}")
    finally:
        con.close()

    if not EVAL_SET.exists():
        check("评估集存在", False, "缺少 starter_set.jsonl")
    else:
        rows = [json.loads(x) for x in EVAL_SET.read_text(encoding="utf-8-sig").splitlines() if x.strip()]
        check("评估集 20 行", len(rows) == 20, f"实际 {len(rows)}")
        counts = {}
        for r in rows:
            counts[r.get("type")] = counts.get(r.get("type"), 0) + 1
        for k, v in EXPECT_EVAL.items():
            check(f"{k} = {v}", counts.get(k, 0) == v, f"实际 {counts.get(k, 0)}")
        ans = [r for r in rows if r.get("type") == "answerable"]
        missing = [r["qid"] for r in ans if not all(k in r for k in ("question", "gold_sql", "columns", "row_count"))]
        check("可答题字段齐全", not missing, "缺: " + ",".join(missing[:5]) if missing else "")
        splits = sorted({r.get("split") for r in ans})
        check("可答题覆盖六种结构", len(splits) == 6, ",".join(splits))

    width = max(len(n) for n, _, _ in results)
    failed = 0
    for name, ok, detail in results:
        if not ok:
            failed += 1
        print(f"[{'PASS' if ok else 'FAIL'}] {name.ljust(width)}  {detail}")
    print("-" * 62)
    if failed:
        print(f"{failed} 项不通过：停手，先修素材（不要把数据问题当代码问题）")
        return 1
    print("全部通过：素材指纹与你拿到的一致，可以开工。")
    print("提示：这三个基准值以后每次重建库都要再对一遍。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
